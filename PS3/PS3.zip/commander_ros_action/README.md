# commander_ros_action

run roscore

to run server first:rosrun commander_ros_action commander_action_server

then run client: rosrun commander_ros_action commander_action_client

Input frequency, amplitude and number of cycles

The server will display callback being executed and velocity being printed out.
## Example usage

## Running tests/demos
    
